package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CounsellingAppointmentSystem {

    private static String registeredUsername = null;
    private static String registeredPassword = null;
    private static String registeredEmail = null;
    private static String registeredMobile = null;

    public CounsellingAppointmentSystem() {
        JFrame frame = new JFrame("Counselling Appointment System");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("Images\\Diadrlogin.jpg"); // Replace with the actual image path
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to fit the panel
            }
        };
        backgroundPanel.setLayout(null); // Use null layout for custom component positioning

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(100, 100, 100, 30);
        backgroundPanel.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(200, 100, 200, 30);
        backgroundPanel.add(userText);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(100, 150, 100, 30);
        backgroundPanel.add(passLabel);

        JPasswordField passField = new JPasswordField();
        passField.setBounds(200, 150, 200, 30);
        backgroundPanel.add(passField);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(150, 250, 100, 30);
        backgroundPanel.add(registerButton);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(300, 250, 100, 30);
        backgroundPanel.add(loginButton);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new RegisterFrame(); // Open registration frame
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enteredUsername = userText.getText().trim();
                String enteredPassword = new String(passField.getPassword()).trim();

                if (registeredUsername == null || registeredPassword == null) {
                    JOptionPane.showMessageDialog(frame, "No user registered!", "Login Failed", JOptionPane.ERROR_MESSAGE);
                } else if (enteredUsername.equals(registeredUsername) && enteredPassword.equals(registeredPassword)) {
                    JOptionPane.showMessageDialog(frame, "Login Successful!", "Login", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                    new ShowDetailsFrame(registeredUsername, registeredEmail, registeredMobile); // Open show details frame
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid username or password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add the background panel to the frame
        frame.setContentPane(backgroundPanel);
        frame.setVisible(true);
    }

    // Getter methods to access private fields
    public static String getRegisteredUsername() {
        return registeredUsername;
    }

    public static String getRegisteredPassword() {
        return registeredPassword;
    }

    public static String getRegisteredEmail() {
        return registeredEmail;
    }

    public static String getRegisteredMobile() {
        return registeredMobile;
    }

    // Setter method to update credentials
    public static void setRegisteredCredentials(String username, String password, String email, String mobile) {
        registeredUsername = username;
        registeredPassword = password;
        registeredEmail = email;
        registeredMobile = mobile;
    }

    public static void main(String[] args) {
        // Create an instance of the CounsellingAppointmentSystem
        new CounsellingAppointmentSystem();
    }
}
