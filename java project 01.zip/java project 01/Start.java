import Classes.*;
import javax.swing.*;

public class Start {

    public static void main(String[] args) {
        // Ensure that the GUI is created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            // Create an instance of the CounsellingAppointmentSystem
            new CounsellingAppointmentSystem();
        });
    }
}
