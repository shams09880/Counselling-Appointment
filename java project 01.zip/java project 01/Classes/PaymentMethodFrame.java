package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PaymentMethodFrame {

    public PaymentMethodFrame(String counsellorName, String totalSessions, String totalCost) {
        JFrame frame = new JFrame("Payment Method");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("Images\\Didar1.jpg"); // Replace with your image path
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to fit the panel
            }
        };
        backgroundPanel.setLayout(new GridLayout(0, 1)); // Use GridLayout for your components

        // Display booking details
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setOpaque(false);  // Make the panel transparent to show the background

        detailsPanel.add(new JLabel("Counsellor Name: " + counsellorName));
        detailsPanel.add(new JLabel("Total Sessions: " + totalSessions));
        detailsPanel.add(new JLabel("Total Cost: $" + totalCost));

        // Payment method selection
        JPanel paymentPanel = new JPanel();
        paymentPanel.setLayout(new BoxLayout(paymentPanel, BoxLayout.Y_AXIS));
        paymentPanel.setOpaque(false);  // Make the panel transparent

        JLabel paymentLabel = new JLabel("Select Payment Method:");
        paymentPanel.add(paymentLabel);

        // Card payment options
        JPanel cardPanel = new JPanel();
        cardPanel.setOpaque(false);  // Transparent background
        String[] cardOptions = {"Visa", "Discover", "American Express", "None"};
        JComboBox<String> cardComboBox = new JComboBox<>(cardOptions);
        cardPanel.add(new JLabel("Card:"));
        cardPanel.add(cardComboBox);
        paymentPanel.add(cardPanel);

        // E-banking payment options
        JPanel eBankingPanel = new JPanel();
        eBankingPanel.setOpaque(false);  // Transparent background
        String[] eBankingOptions = {"Bkash", "Nogod", "Rocket", "None"};
        JComboBox<String> eBankingComboBox = new JComboBox<>(eBankingOptions);
        eBankingPanel.add(new JLabel("E-Banking:"));
        eBankingPanel.add(eBankingComboBox);
        paymentPanel.add(eBankingPanel);

        // Add listeners to ensure only one method is selected at a time
        cardComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!"None".equals(cardComboBox.getSelectedItem())) {
                    eBankingComboBox.setSelectedItem("None"); // Reset e-banking selection if card is selected
                }
            }
        });

        eBankingComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!"None".equals(eBankingComboBox.getSelectedItem())) {
                    cardComboBox.setSelectedItem("None"); // Reset card selection if e-banking is selected
                }
            }
        });

        // Confirm Payment Button
        JButton confirmButton = new JButton("Confirm Payment");
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCard = (String) cardComboBox.getSelectedItem();
                String selectedEBanking = (String) eBankingComboBox.getSelectedItem();

                if ("None".equals(selectedCard) && "None".equals(selectedEBanking)) {
                    JOptionPane.showMessageDialog(frame, "No payment method selected. Please select a valid payment method.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                } else if (selectedCard != null && !"None".equals(selectedCard)) {
                    // Proceed to card information frame
                    new CardInformationFrame(counsellorName, totalSessions, totalCost);
                    frame.dispose(); // Close the payment frame
                } else if (selectedEBanking != null && !"None".equals(selectedEBanking)) {
                    // Proceed to e-banking information frame
                    new EBankingInformationFrame(counsellorName, totalSessions, totalCost);
                    frame.dispose(); // Close the payment frame
                }
            }
        });
        paymentPanel.add(confirmButton);

        // Back Button to switch to SessionBookingsFrame
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close current frame
                new SessionBookingsFrame(counsellorName, "", "", ""); // Switch back to SessionBookingsFrame without passing values
            }
        });
        paymentPanel.add(backButton);

        // Add components to the background panel
        backgroundPanel.add(detailsPanel);
        backgroundPanel.add(paymentPanel);

        // Add the background panel to the frame
        frame.setContentPane(backgroundPanel);
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true);
    }
}
