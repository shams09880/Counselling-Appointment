package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SessionBookingsFrame {

    public SessionBookingsFrame(String name, String expertise, String fees, String sessionTime) {
        JFrame frame = new JFrame("Session Booking for " + name);
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("Images\\didar2.jpg"); // Replace with the path to your image
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Draw the image scaled to fit the panel
            }
        };
        backgroundPanel.setLayout(new GridLayout(0, 1)); // Set layout to manage components

        // Display counsellor details
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(new BoxLayout(detailsPanel, BoxLayout.Y_AXIS));
        detailsPanel.setOpaque(false); // Make the panel transparent to show the background

        detailsPanel.add(new JLabel("Counsellor Name: " + name));
        detailsPanel.add(new JLabel("Expertise: " + expertise));
        detailsPanel.add(new JLabel("Fees per Session: $" + fees));
        detailsPanel.add(new JLabel("Session Time: " + sessionTime));

        // Sessions selection
        JPanel sessionPanel = new JPanel();
        sessionPanel.setOpaque(false); // Make the panel transparent to show the background
        sessionPanel.add(new JLabel("Number of Sessions:"));
        String[] options = {"1", "2"};
        JComboBox<String> sessionComboBox = new JComboBox<>(options);
        sessionPanel.add(sessionComboBox);

        // Next button to proceed to payment
        JButton nextButton = new JButton("Next");
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String selectedSessions = (String) sessionComboBox.getSelectedItem();
                    int totalCost = Integer.parseInt(fees) * Integer.parseInt(selectedSessions); // Calculate total cost
                    new PaymentMethodFrame(name, selectedSessions, String.valueOf(totalCost)); // Pass values to PaymentMethodFrame
                    frame.dispose(); // Close the current frame
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Error in processing fees. Please check the input.", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        sessionPanel.add(nextButton);

        // Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CounsellorListFrame(); // Open the counsellor list again
            }
        });
        sessionPanel.add(backButton);

        // Add components to the background panel
        backgroundPanel.add(detailsPanel);
        backgroundPanel.add(sessionPanel);

        frame.add(backgroundPanel); // Add the background panel to the frame
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true); // Make the frame visible
    }

    // Main method to test the frame (you can remove this in your actual application)
    public static void main(String[] args) {
        new SessionBookingsFrame("John Doe", "Therapy", "100", "10:00 AM");
    }
}
