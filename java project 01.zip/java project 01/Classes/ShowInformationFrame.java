package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ShowInformationFrame {

    public ShowInformationFrame(String counsellorName, String totalSessions, String totalCost,
                                String cardNumber, String cardHolderName, String expiryDate, String cvv) {
        JFrame frame = new JFrame("Show Information");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g); 
                ImageIcon icon = new ImageIcon("Images\\Zumana2.jpg"); // Replace with your image path
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Draw and scale the image to fit panel
            }
        };
        backgroundPanel.setLayout(new BorderLayout());

        // Display all information in the new frame
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);  // Set panel transparency to show the background image

        infoPanel.add(new JLabel("Counsellor: " + counsellorName));
        infoPanel.add(new JLabel("Total Sessions: " + totalSessions));
        infoPanel.add(new JLabel("Total Cost: $" + totalCost));
        infoPanel.add(new JLabel("Card Number: " + cardNumber));
        infoPanel.add(new JLabel("Cardholder Name: " + cardHolderName));
        infoPanel.add(new JLabel("Expiration Date: " + expiryDate));
        infoPanel.add(new JLabel("CVV: " + cvv));

        // Create the button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false); // Set transparency for buttons as well

        JButton backButton = new JButton("Back");
        JButton nextButton = new JButton("Next");

        // Add action listeners for buttons
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cardNumber.equals("Phone Transaction")) {
                    new EBankingInformationFrame(counsellorName, totalSessions, totalCost);
                } else {
                    new CardInformationFrame(counsellorName, totalSessions, totalCost);
                }
                frame.dispose(); // Close current frame
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Next button clicked");
                new ReviewFrame(); // Switch to Review frame
                frame.dispose(); // Close current frame
            }
        });

        // Add buttons to the button panel
        buttonPanel.add(backButton);
        buttonPanel.add(nextButton);

        // Add the info panel and button panel to the background panel
        backgroundPanel.add(infoPanel, BorderLayout.CENTER);
        backgroundPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add the background panel to the frame
        frame.add(backgroundPanel);

        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true); // Make the frame visible
    }

    // Main method to test the ShowInformationFrame
    public static void main(String[] args) {
        // Testing with card payment
        new ShowInformationFrame("Dr. Smith", "5", "500", "1234-5678-9012-3456", "John Doe", "12/25", "123");

        // Testing with e-banking payment
        // new ShowInformationFrame("Dr. Smith", "5", "500", "Phone Transaction", "N/A", "N/A", "TXN123456");
    }
}
