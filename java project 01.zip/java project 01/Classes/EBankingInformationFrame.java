package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EBankingInformationFrame {
    public EBankingInformationFrame(String counsellorName, String totalSessions, String totalCost) {
        JFrame frame = new JFrame("E-Banking Information");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a custom panel with background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);    
                ImageIcon backgroundIcon = new ImageIcon("Images\\images (3).jpeg.jpg"); // Replace with your image path
                Image backgroundImage = backgroundIcon.getImage();
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        backgroundPanel.setLayout(new GridLayout(0, 1)); // Use GridLayout for form layout

        // E-banking information fields
        JPanel eBankingPanel = new JPanel();
        eBankingPanel.setLayout(new BoxLayout(eBankingPanel, BoxLayout.Y_AXIS));
        eBankingPanel.setOpaque(false); // Make the panel transparent so the background is visible

        eBankingPanel.add(new JLabel("Enter Phone Number:"));
        JTextField phoneNumberField = new JTextField();
        eBankingPanel.add(phoneNumberField);

        eBankingPanel.add(new JLabel("Enter Transaction ID:"));
        JTextField transactionIdField = new JTextField();
        eBankingPanel.add(transactionIdField);

        // Confirm button
        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Logic for processing e-banking information
                JOptionPane.showMessageDialog(frame, "E-banking information confirmed!\n" +
                        "Counsellor: " + counsellorName + "\n" +
                        "Total Sessions: " + totalSessions + "\n" +
                        "Total Cost: $" + totalCost,
                        "Confirmation", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Switch back to PaymentMethodFrame
                frame.dispose(); // Close the current EBankingInformationFrame
                new PaymentMethodFrame(counsellorName, totalSessions, totalCost); // Open PaymentMethodFrame
            }
        });

        // Next button (larger size)
        JButton nextButton = new JButton("Next");
        nextButton.setPreferredSize(new Dimension(120, 40));  // Make the Next button larger
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Switch to ShowInformationFrame and pass information
                String phoneNumber = phoneNumberField.getText();
                String transactionId = transactionIdField.getText();
                
                new ShowInformationFrame(counsellorName, totalSessions, totalCost, 
                        phoneNumber, "Phone Transaction", "N/A", transactionId);  // Pass necessary info
                
                frame.dispose(); // Close the current frame
            }
        });

        // Add buttons to the panel
        eBankingPanel.add(confirmButton);
        eBankingPanel.add(backButton);
        eBankingPanel.add(nextButton); // Add the larger Next button

        backgroundPanel.add(eBankingPanel); // Add eBankingPanel to the background panel
        frame.add(backgroundPanel); // Add the background panel to the frame
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true); // Make the frame visible
    }

    // Main method to test the EBankingInformationFrame
    public static void main(String[] args) {
        new EBankingInformationFrame("Dr. Smith", "5", "500");
    }
}
