package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.time.*;
import java.time.format.*;

public class RegisterFrame {

    public RegisterFrame() {
        JFrame frame = new JFrame("Register");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);   
                ImageIcon icon = new ImageIcon("F:\\bal 2\\Images\\register.jpg"); // Replace with your image path
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to fit the panel
            }
        };
        backgroundPanel.setLayout(null); // Use null layout for custom component positioning

        // Add labels and input fields for registration
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(100, 100, 100, 30);
        backgroundPanel.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(250, 100, 200, 30);
        backgroundPanel.add(userText);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(100, 150, 100, 30);
        backgroundPanel.add(emailLabel);

        JTextField emailText = new JTextField();
        emailText.setBounds(250, 150, 200, 30);
        backgroundPanel.add(emailText);

        JLabel mobileLabel = new JLabel("Mobile Number:");
        mobileLabel.setBounds(100, 200, 150, 30);
        backgroundPanel.add(mobileLabel);

        JTextField mobileText = new JTextField();
        mobileText.setBounds(250, 200, 200, 30);
        backgroundPanel.add(mobileText);

        // Add KeyListener to restrict mobileText to numbers only
        mobileText.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(100, 250, 100, 30);
        backgroundPanel.add(passLabel);

        JPasswordField passField = new JPasswordField();
        passField.setBounds(250, 250, 200, 30);
        backgroundPanel.add(passField);

        JLabel retypePassLabel = new JLabel("Retype Password:");
        retypePassLabel.setBounds(100, 300, 150, 30);
        backgroundPanel.add(retypePassLabel);

        JPasswordField retypePassField = new JPasswordField();
        retypePassField.setBounds(250, 300, 200, 30);
        backgroundPanel.add(retypePassField);

        JButton backButton = new JButton("Back");
        backButton.setBounds(150, 400, 100, 30);
        backgroundPanel.add(backButton);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(300, 400, 100, 30);
        backgroundPanel.add(registerButton);

        // Handle registration logic when the "Register" button is clicked
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText().trim();
                String email = emailText.getText().trim();
                String mobile = mobileText.getText().trim();
                String password = new String(passField.getPassword()).trim();
                String retypePassword = new String(retypePassField.getPassword()).trim();

                // Validate form inputs
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Username and Password cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (!password.equals(retypePassword)) {
                    JOptionPane.showMessageDialog(frame, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        // Create or append to the user_data.txt file
                        File file = new File("UserData.txt");
                        if (!file.exists()) {
                            file.createNewFile();
                        }
                        FileWriter fw = new FileWriter(file, true);
                        BufferedWriter bw = new BufferedWriter(fw);
                        PrintWriter pw = new PrintWriter(bw);

                        // Get current date and time
                        LocalDateTime myDateObj = LocalDateTime.now();
                        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm a, dd/MM/yyyy");
                        String timeAndDate = myDateObj.format(myFormatObj);

                        // Write user details to the file
                        pw.println("User Name : " + username);
                        pw.println("Password : " + password);
                        pw.println("Email : " + email);
                        pw.println("Mobile Number : " + mobile);
                        pw.println("Registered at : " + timeAndDate);
                        pw.println("=======Didar...Shuvro========");

                        pw.close();

                        // Store the registered credentials in CounsellingAppointmentSystem static fields
                        CounsellingAppointmentSystem.setRegisteredCredentials(username, password, email, mobile);

                        // Show success message
                        JOptionPane.showMessageDialog(frame, "Registration Successfully Completed!\nYou can log in now.", "Registration Complete", JOptionPane.INFORMATION_MESSAGE);

                        // Clear the form
                        userText.setText("");
                        emailText.setText("");
                        mobileText.setText("");
                        passField.setText("");
                        retypePassField.setText("");

                    } catch (IOException ex) {
                        System.out.println("Error: " + ex.getMessage());
                    }
                }
            }
        });

        // Handle "Back" button click
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CounsellingAppointmentSystem(); // Return to the login screen
            }
        });

        // Add the background panel to the frame
        frame.setContentPane(backgroundPanel);
        frame.setVisible(true);
    }
}
