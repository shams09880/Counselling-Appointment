package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CounsellorListFrame {

    public CounsellorListFrame() {
        // Create JFrame with specified size
        JFrame frame = new JFrame("Counsellor List");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a custom panel with background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);        
                ImageIcon backgroundIcon = new ImageIcon("Images\\black1.jpg"); // Add your image path here
                Image backgroundImage = backgroundIcon.getImage();
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        backgroundPanel.setLayout(new BorderLayout());

        // Create a scrollable panel to hold the counsellor list
        JPanel mainPanel = new JPanel();
        mainPanel.setOpaque(false); // Ensure transparency to see the background
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS)); // Use vertical BoxLayout

        // Sample counsellor data
        String[][] counsellors = {
            {"Counsellor 9", "Anxiety", "50", "1 hour"},
            {"Counsellor 72", "Relationship conflicts", "60", "1.5 hours"},
            {"Counsellor 26", "Study Management", "40", "45 minutes"}
        };

        // Loop through counsellors to create panels for each
        for (String[] counsellor : counsellors) {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Vertical layout for each counsellor
            panel.setOpaque(false); // Ensure transparency to see the background

            JTextArea textArea = new JTextArea();
            textArea.setText(String.format("Name: %s\nExpertise: %s\nFees: $%s\nSession Time: %s",
                    counsellor[0], counsellor[1], counsellor[2], counsellor[3]));
            textArea.setEditable(false);
            textArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            textArea.setPreferredSize(new Dimension(300, 100)); // Set preferred size for the text area
            panel.add(textArea);

            JButton bookButton = new JButton("Book");
            bookButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    new SessionBookingsFrame(counsellor[0], counsellor[1], counsellor[2], counsellor[3]);
                    frame.dispose(); // Close the counsellor list frame
                }
            });
            panel.add(bookButton);

            // Add some spacing between counsellor entries
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            mainPanel.add(panel); // Add each counsellor panel to the main panel
        }

        // Add Back button
        JButton backButton = new JButton("Back");
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT); // Center the button
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the current frame
                new MyProfileFrame(); // Switch to MyProfileFrame
            }
        });

        mainPanel.add(backButton); // Add the Back button to the main panel

        // Make the panel scrollable
        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false); // Make scroll pane transparent
        backgroundPanel.add(scrollPane, BorderLayout.CENTER); // Add the scroll pane to the background panel

        frame.add(backgroundPanel); // Add the background panel to the frame
        frame.setLocationRelativeTo(null); // Center the frame on the screen
        frame.setVisible(true); // Make the frame visible
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CounsellorListFrame()); // Start the application
    }
}

