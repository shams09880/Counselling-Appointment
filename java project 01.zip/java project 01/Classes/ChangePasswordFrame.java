package Classes;
import javax.swing.*; // For JFrame, JButton, JLabel, JOptionPane, etc.
import java.awt.*; // For Graphics, Image, etc.
import java.awt.event.ActionEvent; // For ActionEvent
import java.awt.event.ActionListener; // For ActionListener

public class ChangePasswordFrame {

    private JFrame frame;

    public ChangePasswordFrame(ShowDetailsFrame previousFrame) {
        frame = new JFrame("Change Password");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a custom panel with background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);        
                ImageIcon backgroundIcon = new ImageIcon("F:\\bal 2\\Images\\Didar3.jpg"); // Add your image path here
                Image backgroundImage = backgroundIcon.getImage();
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        backgroundPanel.setLayout(null); // Use absolute positioning for components

        // Labels and Password Fields
        JLabel oldPasswordLabel = new JLabel("Old Password:");
        oldPasswordLabel.setBounds(100, 100, 200, 30);
        backgroundPanel.add(oldPasswordLabel);

        JPasswordField oldPasswordField = new JPasswordField();
        oldPasswordField.setBounds(300, 100, 200, 30);
        backgroundPanel.add(oldPasswordField);

        JLabel newPasswordLabel = new JLabel("New Password:");
        newPasswordLabel.setBounds(100, 150, 200, 30);
        backgroundPanel.add(newPasswordLabel);

        JPasswordField newPasswordField = new JPasswordField();
        newPasswordField.setBounds(300, 150, 200, 30);
        backgroundPanel.add(newPasswordField);

        JLabel retypeNewPasswordLabel = new JLabel("Re-type New Password:");
        retypeNewPasswordLabel.setBounds(100, 200, 200, 30);
        backgroundPanel.add(retypeNewPasswordLabel);

        JPasswordField retypeNewPasswordField = new JPasswordField();
        retypeNewPasswordField.setBounds(300, 200, 200, 30);
        backgroundPanel.add(retypeNewPasswordField);

        // Confirm button to validate and change the password
        JButton confirmButton = new JButton("Confirm");
        confirmButton.setBounds(300, 300, 150, 50);
        backgroundPanel.add(confirmButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(100, 300, 150, 50);
        backgroundPanel.add(backButton);

        // Back button to return to the ShowDetailsFrame
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the change password frame
                previousFrame.show(); // Show the previous frame (ShowDetailsFrame)
            }
        });

        // Confirm button logic to validate the password change
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String oldPassword = new String(oldPasswordField.getPassword());
                String newPassword = new String(newPasswordField.getPassword());
                String retypeNewPassword = new String(retypeNewPasswordField.getPassword());

                // Check if old password matches the registered one
                if (!oldPassword.equals(CounsellingAppointmentSystem.getRegisteredPassword())) {
                    JOptionPane.showMessageDialog(frame, "Old password is incorrect!", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (newPassword.equals(retypeNewPassword)) {
                    // Update the registered password
                    CounsellingAppointmentSystem.setRegisteredCredentials(
                        CounsellingAppointmentSystem.getRegisteredUsername(),
                        newPassword,
                        CounsellingAppointmentSystem.getRegisteredEmail(),
                        CounsellingAppointmentSystem.getRegisteredMobile()
                    );

                    JOptionPane.showMessageDialog(frame, "Password changed successfully!");
                    frame.dispose(); // Close the current frame after confirmation
                    previousFrame.show(); // Show the ShowDetailsFrame again
                } else {
                    JOptionPane.showMessageDialog(frame, "New passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add the background panel to the frame
        frame.setContentPane(backgroundPanel);
        frame.setVisible(true);
    }
}
