package Classes;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyProfileFrame {

    public MyProfileFrame() {
        JFrame frame = new JFrame("My Profile");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);     
                ImageIcon icon = new ImageIcon("Images\\my profile.jpg"); // Replace with your image path
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to fit the panel
            }
        };
        backgroundPanel.setLayout(null); // Set layout to null for custom positioning

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(100, 50, 150, 30);
        backgroundPanel.add(usernameLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(250, 50, 300, 30);
        backgroundPanel.add(usernameField);

        JLabel fullNameLabel = new JLabel("Full Name:");
        fullNameLabel.setBounds(100, 100, 150, 30);
        backgroundPanel.add(fullNameLabel);

        JTextField fullNameField = new JTextField();
        fullNameField.setBounds(250, 100, 300, 30);
        backgroundPanel.add(fullNameField);

        JLabel matricIdLabel = new JLabel("Matric ID:");
        matricIdLabel.setBounds(100, 150, 150, 30);
        backgroundPanel.add(matricIdLabel);

        JTextField matricIdField = new JTextField();
        matricIdField.setBounds(250, 150, 300, 30);
        backgroundPanel.add(matricIdField);

        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setBounds(100, 200, 150, 30);
        backgroundPanel.add(addressLabel);

        JTextField addressField = new JTextField();
        addressField.setBounds(250, 200, 300, 30);
        backgroundPanel.add(addressField);

        JLabel dobLabel = new JLabel("Date of Birth:");
        dobLabel.setBounds(100, 250, 150, 30);
        backgroundPanel.add(dobLabel);

        JTextField dobField = new JTextField();
        dobField.setBounds(250, 250, 300, 30);
        backgroundPanel.add(dobField);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(100, 300, 150, 30);
        backgroundPanel.add(genderLabel);

        String[] genderOptions = {"Male", "Female", "Others"};
        JComboBox<String> genderComboBox = new JComboBox<>(genderOptions);
        genderComboBox.setBounds(250, 300, 300, 30);
        backgroundPanel.add(genderComboBox);

        // Back button to switch to ShowDetailsFrame
        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 400, 100, 40);
        backgroundPanel.add(backButton);

        // Next button to switch to CounsellorListFrame, disabled initially
        JButton nextButton = new JButton("Next");
        nextButton.setBounds(150, 400, 100, 40);
        nextButton.setEnabled(false);  // Disable the button initially
        backgroundPanel.add(nextButton);

        // Submit button to show the profile details
        JButton submitButton = new JButton("Submit");
        submitButton.setBounds(300, 400, 150, 50);
        backgroundPanel.add(submitButton);

        // Method to check if all fields are filled
        ActionListener checkFieldsFilled = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!usernameField.getText().trim().isEmpty() &&
                        !fullNameField.getText().trim().isEmpty() &&
                        !matricIdField.getText().trim().isEmpty() &&
                        !addressField.getText().trim().isEmpty() &&
                        !dobField.getText().trim().isEmpty()) {
                    nextButton.setEnabled(true);
                } else {
                    nextButton.setEnabled(false);
                }
            }
        };

        // Attach DocumentListeners to text fields to monitor input
        usernameField.getDocument().addDocumentListener(new FieldDocumentListener(checkFieldsFilled));
        fullNameField.getDocument().addDocumentListener(new FieldDocumentListener(checkFieldsFilled));
        matricIdField.getDocument().addDocumentListener(new FieldDocumentListener(checkFieldsFilled));
        addressField.getDocument().addDocumentListener(new FieldDocumentListener(checkFieldsFilled));
        dobField.getDocument().addDocumentListener(new FieldDocumentListener(checkFieldsFilled));

        // ActionListener for Next button
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CounsellorListFrame();
            }
        });

        // ActionListener for Submit button
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String fullName = fullNameField.getText();
                String matricId = matricIdField.getText();
                String address = addressField.getText();
                String dob = dobField.getText();
                String gender = (String) genderComboBox.getSelectedItem();

                JOptionPane.showMessageDialog(frame,
                        "Username: " + username + "\n" +
                                "Full Name: " + fullName + "\n" +
                                "Matric ID: " + matricId + "\n" +
                                "Address: " + address + "\n" +
                                "Date of Birth: " + dob + "\n" +
                                "Gender: " + gender, "Profile Information", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // ActionListener for Back button
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new ShowDetailsFrame("DefaultUser", "default@example.com", "1234567890");
            }
        });

        // Add the background panel to the frame
        frame.setContentPane(backgroundPanel);
        frame.setVisible(true);
    }

    // DocumentListener to detect text field changes
    private static class FieldDocumentListener implements DocumentListener {
        private final ActionListener listener;

        public FieldDocumentListener(ActionListener listener) {
            this.listener = listener;
        }

        @Override
        public void insertUpdate(DocumentEvent e) {
            listener.actionPerformed(null);
        }

        @Override
        public void removeUpdate(DocumentEvent e) {
            listener.actionPerformed(null);
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            listener.actionPerformed(null);
        }
    }

    public static void main(String[] args) {
        new MyProfileFrame();
    }
}
