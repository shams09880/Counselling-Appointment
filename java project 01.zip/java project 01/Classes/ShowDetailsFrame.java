package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ShowDetailsFrame {

    private JFrame frame;

    public ShowDetailsFrame(String username, String email, String mobile) {
        frame = new JFrame("Show Details");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override              
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);   
                ImageIcon icon = new ImageIcon("Images\\Didar23.jpg"); // Replace with your image path
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Scale image to fit the panel
            }
        };
        backgroundPanel.setLayout(null); // Use null layout for custom component positioning

        JLabel userLabel = new JLabel("Username: " + username);
        userLabel.setBounds(100, 100, 400, 30);
        backgroundPanel.add(userLabel);

        JLabel emailLabel = new JLabel("Email: " + email);
        emailLabel.setBounds(100, 150, 400, 30);
        backgroundPanel.add(emailLabel);

        JLabel mobileLabel = new JLabel("Mobile Number: " + mobile);
        mobileLabel.setBounds(100, 200, 400, 30);
        backgroundPanel.add(mobileLabel);

        JButton changePasswordButton = new JButton("Change Password");
        changePasswordButton.setBounds(150, 300, 200, 50);
        backgroundPanel.add(changePasswordButton);

        JButton nextButton = new JButton("Next");
        nextButton.setBounds(400, 300, 150, 50);
        backgroundPanel.add(nextButton);

        // New Back button to switch back to CounsellingAppointmentSystem
        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 400, 100, 50);
        backgroundPanel.add(backButton);

        // Switch to ChangePasswordFrame
        changePasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false); // Hide the current frame but don't dispose it
                new ChangePasswordFrame(ShowDetailsFrame.this);
            }
        });

        // Switch to MyProfileFrame
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close current frame
                new MyProfileFrame();
            }
        });

        // ActionListener for Back button to switch to CounsellingAppointmentSystem
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close current frame
                new CounsellingAppointmentSystem(); // Open CounsellingAppointmentSystem
            }
        });

        // Add the background panel to the frame
        frame.setContentPane(backgroundPanel);
        frame.setVisible(true);
    }

    // To make the frame visible again when switching back
    public void show() {
        frame.setVisible(true);
    }

    // To hide the frame
    public void hide() {
        frame.setVisible(false);
    }
}
