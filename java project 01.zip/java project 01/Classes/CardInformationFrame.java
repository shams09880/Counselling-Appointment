package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CardInformationFrame {

    public CardInformationFrame(String counsellorName, String totalSessions, String totalCost) {
        JFrame frame = new JFrame("Card Information");
        frame.setSize(1200, 675);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a panel with a background image
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon("Images\\bank.jpg"); // Replace with your image path
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this); // Draw the image scaled to fit panel
            }
        };
        backgroundPanel.setLayout(new GridLayout(0, 1));  // Set layout to manage components

        // Card information fields
        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));
        cardPanel.setOpaque(false); // Set panel transparency to show background image

        cardPanel.add(new JLabel("Enter Card Number:"));
        JTextField cardNumberField = new JTextField();
        cardPanel.add(cardNumberField);

        cardPanel.add(new JLabel("Enter Cardholder Name:"));
        JTextField cardHolderField = new JTextField();
        cardPanel.add(cardHolderField);

        cardPanel.add(new JLabel("Enter Expiration Date (MM/YY):"));
        JTextField expiryField = new JTextField();
        cardPanel.add(expiryField);

        cardPanel.add(new JLabel("Enter CVV:"));
        JTextField cvvField = new JTextField();
        cardPanel.add(cvvField);

        // Confirm button
        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Gather card information
                String cardNumber = cardNumberField.getText();
                String cardHolderName = cardHolderField.getText();
                String expiryDate = expiryField.getText();
                String cvv = cvvField.getText();

                // Show the new frame with the information
                new ShowInformationFrame(counsellorName, totalSessions, totalCost, cardNumber, cardHolderName, expiryDate, cvv);
                frame.dispose(); // Close the current frame
            }
        });

        // Back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Switch back to PaymentMethodFrame (without passing values)
                frame.dispose(); // Close the current CardInformationFrame
                new PaymentMethodFrame("", "", ""); // Open PaymentMethodFrame without passing any values
            }
        });

        cardPanel.add(confirmButton);
        cardPanel.add(backButton);

        backgroundPanel.add(cardPanel);  // Add card panel to the background panel
        frame.add(backgroundPanel);  // Add background panel to the frame

        frame.setLocationRelativeTo(null); // Center the frame
        frame.setVisible(true); // Make the frame visible
    }

   
}
