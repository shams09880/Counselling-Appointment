package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReviewFrame {
    public ReviewFrame() {
        JFrame reviewFrame = new JFrame("Review & Ratings");
        reviewFrame.setSize(1200, 675);
        reviewFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        reviewFrame.setLayout(new BorderLayout());

        // Panel to hold review and rating components
        JPanel reviewPanel = new JPanel();
        reviewPanel.setLayout(new BoxLayout(reviewPanel, BoxLayout.Y_AXIS));

        // Add a label for instructions
        reviewPanel.add(new JLabel("Please provide your review and rating:"));

        // Text area for review, make it smaller
        JTextArea reviewTextArea = new JTextArea(5, 40);  // Reduced size
        reviewTextArea.setLineWrap(true);
        reviewTextArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(reviewTextArea);
        reviewPanel.add(scrollPane);

        // Panel for ratings with green background and smaller combo box
        JPanel ratingPanel = new JPanel();
        ratingPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        ratingPanel.setBackground(Color.GREEN); // Set background color to green

        JLabel ratingLabel = new JLabel("Rating:");
        String[] ratings = {"1 Star", "2 Stars", "3 Stars", "4 Stars", "5 Stars"};
        JComboBox<String> ratingComboBox = new JComboBox<>(ratings);
        ratingComboBox.setPreferredSize(new Dimension(100, 25));  // Reduced size of combo box

        // Set the light green background color for the combo box
        ratingComboBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                c.setBackground(isSelected ? Color.GREEN : Color.LIGHT_GRAY);  // Set the background color to light green
                return c;
            }
        });

        ratingPanel.add(ratingLabel);
        ratingPanel.add(ratingComboBox);

        // Add the rating panel (with green background) to the reviewPanel
        reviewPanel.add(ratingPanel);

        // Create a new panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton backButton = new JButton("Back");
        JButton logoutButton = new JButton("Logout");
        JButton confirmButton = new JButton("Confirm");  // New Confirm button

        // Add action listeners for buttons
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle back button click
                System.out.println("Back button clicked");
                // Switch back to the ShowInformationFrame
                new ShowInformationFrame("Dr. Smith", "5", "500", "1234-5678-9012-3456", 
                        "John Doe", "12/25", "123"); // Use same default values or pass any other values
                reviewFrame.dispose();  // Close current frame
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle logout button click
                System.out.println("Logout button clicked");
                // Add logic for logout, e.g., redirect to login screen
                JOptionPane.showMessageDialog(reviewFrame, "You have logged out!");

                // Switch back to CounsellingAppointmentSystem (login system)
                new CounsellingAppointmentSystem();

                // Close the current frame
                reviewFrame.dispose();
            }
        });

        // Add action listener for Confirm button
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Retrieve review text and selected rating
                String reviewText = reviewTextArea.getText().trim();
                String selectedRating = (String) ratingComboBox.getSelectedItem();

                // Check if the review is empty
                if (reviewText.isEmpty()) {
                    JOptionPane.showMessageDialog(reviewFrame, "Please provide a review before confirming.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Display a confirmation dialog with the review and rating
                    JOptionPane.showMessageDialog(reviewFrame, 
                        "Your review: " + reviewText + "\nYour rating: " + selectedRating, 
                        "Review Confirmed", JOptionPane.INFORMATION_MESSAGE);

                    // Here you can add additional logic to save the review/rating
                    System.out.println("Review: " + reviewText);
                    System.out.println("Rating: " + selectedRating);
                }
            }
        });

        // Add buttons to the button panel
        buttonPanel.add(backButton);
        buttonPanel.add(logoutButton);
        buttonPanel.add(confirmButton);  // Add Confirm button to the panel

        // Add the review panel and buttons to the frame
        reviewFrame.add(reviewPanel, BorderLayout.CENTER);
        reviewFrame.add(buttonPanel, BorderLayout.SOUTH); // Buttons placed under the combo box

        reviewFrame.setLocationRelativeTo(null); // Center the frame
        reviewFrame.setVisible(true); // Make the frame visible
    }

    // Main method for testing
    public static void main(String[] args) {
        new ReviewFrame();
    }
}
